const STORAGE_KEY = 'codveda.todos.v1';

const list = document.getElementById('list');
const form = document.getElementById('addForm');
const input = document.getElementById('newTask');
const errorEl = document.getElementById('formError');
const emptyEl = document.getElementById('empty');
const countEl = document.getElementById('count');

let tasks = load();
let filter = 'all';
let editingId = null;

// ---------- Storage ----------
function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// ---------- Actions ----------
function addTask(text) {
  tasks.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text, done: false });
  save(); render();
}
function toggleTask(id) {
  const t = tasks.find((x) => x.id === id);
  if (t) { t.done = !t.done; save(); render(); }
}
function updateTask(id, text) {
  const t = tasks.find((x) => x.id === id);
  if (t && text.trim()) t.text = text.trim();
  editingId = null;
  save(); render();
}
function deleteTask(id) {
  tasks = tasks.filter((x) => x.id !== id);
  save(); render();
}

// ---------- Render ----------
function render() {
  list.innerHTML = '';
  const visible = tasks.filter((t) =>
    filter === 'all' ? true : filter === 'done' ? t.done : !t.done
  );

  visible.forEach((t) => {
    const li = document.createElement('li');
    li.className = 'item' + (t.done ? ' done' : '');
    li.dataset.id = t.id;

    const box = document.createElement('input');
    box.type = 'checkbox';
    box.checked = t.done;
    box.setAttribute('aria-label', 'Mark "' + t.text + '" as complete');
    box.addEventListener('change', () => toggleTask(t.id));
    li.appendChild(box);

    if (editingId === t.id) {
      const edit = document.createElement('input');
      edit.className = 'edit';
      edit.value = t.text;
      edit.maxLength = 120;
      edit.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') updateTask(t.id, edit.value);
        if (e.key === 'Escape') { editingId = null; render(); }
      });
      edit.addEventListener('blur', () => { if (editingId === t.id) updateTask(t.id, edit.value); });
      li.appendChild(edit);
      list.appendChild(li);
      edit.focus();
      edit.setSelectionRange(edit.value.length, edit.value.length);
      return;
    }

    const span = document.createElement('span');
    span.className = 'text';
    span.textContent = t.text;           // textContent prevents HTML injection
    span.addEventListener('dblclick', () => { editingId = t.id; render(); });
    li.appendChild(span);

    const editBtn = document.createElement('button');
    editBtn.className = 'icon';
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => { editingId = t.id; render(); });
    li.appendChild(editBtn);

    const delBtn = document.createElement('button');
    delBtn.className = 'icon del';
    delBtn.textContent = 'Delete';
    delBtn.setAttribute('aria-label', 'Delete "' + t.text + '"');
    delBtn.addEventListener('click', () => deleteTask(t.id));
    li.appendChild(delBtn);

    list.appendChild(li);
  });

  emptyEl.hidden = visible.length > 0;
  const left = tasks.filter((t) => !t.done).length;
  countEl.textContent = left + (left === 1 ? ' task left' : ' tasks left');
}

// ---------- Events ----------
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) {
    errorEl.textContent = 'Type a task before adding it.';
    input.focus();
    return;
  }
  errorEl.textContent = '';
  addTask(text);
  input.value = '';
  input.focus();
});

document.querySelectorAll('.filter').forEach((btn) => {
  btn.addEventListener('click', () => {
    filter = btn.dataset.filter;
    document.querySelectorAll('.filter').forEach((b) => b.classList.toggle('active', b === btn));
    render();
  });
});

document.getElementById('clearDone').addEventListener('click', () => {
  tasks = tasks.filter((t) => !t.done);
  save(); render();
});

render();
