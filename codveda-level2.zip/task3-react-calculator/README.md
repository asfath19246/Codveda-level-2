# React Calculator (Vite)

Create React App is no longer maintained, so this project uses Vite, the current recommended way to start a React project.

## Run
    npm install
    npm run dev       # open the URL shown (usually http://localhost:5173)
    npm test          # runs the calculator logic tests (no install needed)
    npm run build     # production build

## Concepts shown
- Components: App, Display, Keypad, Key (src/components)
- Props: Display (value, expression), Keypad (onPress), Key (label, variant, wide, onPress)
- State: useState in App holds the calculator state; calc.js has the pure logic
- Effects: useEffect adds keyboard support
