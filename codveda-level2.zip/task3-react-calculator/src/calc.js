// Pure calculator logic (no React) so it is easy to test.
export const initialState = { current: '0', previous: null, op: null, overwrite: false };

export function compute(a, b, op) {
  const x = parseFloat(a);
  const y = parseFloat(b);
  let r;
  switch (op) {
    case '+': r = x + y; break;
    case '−': r = x - y; break;
    case '×': r = x * y; break;
    case '÷':
      if (y === 0) return 'Error';
      r = x / y;
      break;
    default: return b;
  }
  return String(parseFloat(r.toPrecision(12)));
}

const safe = (s) => (s.current === 'Error' ? initialState : s);

export function inputDigit(state, d) {
  const s = safe(state);
  if (s.overwrite) return { ...s, current: d, overwrite: false };
  if (s.current === '0') return { ...s, current: d };
  if (s.current.replace(/[-.]/g, '').length >= 12) return s;
  return { ...s, current: s.current + d };
}

export function inputDot(state) {
  const s = safe(state);
  if (s.overwrite) return { ...s, current: '0.', overwrite: false };
  if (s.current.includes('.')) return s;
  return { ...s, current: s.current + '.' };
}

export function chooseOp(state, op) {
  if (state.current === 'Error') return state;
  if (state.op && state.overwrite) return { ...state, op };          // change operator
  if (state.op && state.previous !== null) {                         // chain: 2 + 3 +
    const result = compute(state.previous, state.current, state.op);
    return { current: result, previous: result, op, overwrite: true };
  }
  return { ...state, previous: state.current, op, overwrite: true };
}

export function equals(state) {
  if (!state.op || state.previous === null) return state;
  const result = compute(state.previous, state.current, state.op);
  return { current: result, previous: null, op: null, overwrite: true };
}

export function backspace(state) {
  if (state.overwrite || state.current === 'Error') return state;
  const next = state.current.slice(0, -1);
  return { ...state, current: next === '' || next === '-' ? '0' : next };
}

export function negate(state) {
  if (state.current === '0' || state.current === 'Error') return state;
  return { ...state, current: state.current.startsWith('-') ? state.current.slice(1) : '-' + state.current };
}

export function percent(state) {
  if (state.current === 'Error') return state;
  return { ...state, current: String(parseFloat((parseFloat(state.current) / 100).toPrecision(12))), overwrite: true };
}
