// Props: label, variant ('num' | 'op' | 'fn' | 'eq'), wide, onPress
export default function Key({ label, variant = 'num', wide = false, onPress }) {
  return (
    <button
      className={`key ${variant}${wide ? ' wide' : ''}`}
      onClick={() => onPress(label)}
    >
      {label}
    </button>
  );
}
