import Key from './Key.jsx';

const KEYS = [
  { label: 'C', variant: 'fn' }, { label: '±', variant: 'fn' }, { label: '%', variant: 'fn' }, { label: '÷', variant: 'op' },
  { label: '7' }, { label: '8' }, { label: '9' }, { label: '×', variant: 'op' },
  { label: '4' }, { label: '5' }, { label: '6' }, { label: '−', variant: 'op' },
  { label: '1' }, { label: '2' }, { label: '3' }, { label: '+', variant: 'op' },
  { label: '0', wide: true }, { label: '.' }, { label: '=', variant: 'eq' }
];

// Props: onPress(label)
export default function Keypad({ onPress }) {
  return (
    <div className="keypad">
      {KEYS.map((k) => (
        <Key key={k.label} {...k} onPress={onPress} />
      ))}
    </div>
  );
}
