// Props: value (string), expression (string)
export default function Display({ value, expression }) {
  return (
    <div className="display" aria-live="polite">
      <div className="expr">{expression || '\u00A0'}</div>
      <div className="value" data-long={value.length > 9}>{value}</div>
    </div>
  );
}
