import { useState, useEffect } from 'react';
import Display from './components/Display.jsx';
import Keypad from './components/Keypad.jsx';
import * as calc from './calc.js';

export default function App() {
  // State: all calculator data lives in one object
  const [state, setState] = useState(calc.initialState);

  function handlePress(label) {
    setState((s) => {
      if (/^[0-9]$/.test(label)) return calc.inputDigit(s, label);
      switch (label) {
        case '.': return calc.inputDot(s);
        case '=': return calc.equals(s);
        case 'C': return calc.initialState;
        case '±': return calc.negate(s);
        case '%': return calc.percent(s);
        case '⌫': return calc.backspace(s);
        default: return calc.chooseOp(s, label);
      }
    });
  }

  // Keyboard support
  useEffect(() => {
    const map = { '*': '×', '/': '÷', '-': '−', Enter: '=', Backspace: '⌫', Escape: 'C' };
    function onKey(e) {
      const k = map[e.key] ?? e.key;
      if (/^[0-9.+=%]$/.test(k) || ['×', '÷', '−', '⌫', 'C'].includes(k)) {
        e.preventDefault();
        handlePress(k);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const expression = state.op ? `${state.previous} ${state.op}` : '';

  return (
    <main className="calc">
      <h1>Calculator</h1>
      <Display value={state.current} expression={expression} />
      <Keypad onPress={handlePress} />
    </main>
  );
}
