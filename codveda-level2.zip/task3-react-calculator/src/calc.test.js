import assert from 'node:assert/strict';
import * as c from './calc.js';

const press = (state, keys) => keys.reduce((s, k) => {
  if (/^[0-9]$/.test(k)) return c.inputDigit(s, k);
  if (k === '.') return c.inputDot(s);
  if (k === '=') return c.equals(s);
  if (k === 'C') return c.initialState;
  if (k === '±') return c.negate(s);
  if (k === '%') return c.percent(s);
  if (k === '⌫') return c.backspace(s);
  return c.chooseOp(s, k);
}, state);

const run = (keys) => press(c.initialState, keys.split(' ')).current;

assert.equal(run('2 + 3 ='), '5');
assert.equal(run('9 − 4 ='), '5');
assert.equal(run('6 × 7 ='), '42');
assert.equal(run('8 ÷ 4 ='), '2');
assert.equal(run('5 ÷ 0 ='), 'Error');
assert.equal(run('0 . 1 + 0 . 2 ='), '0.3');
assert.equal(run('2 + 3 + 4 ='), '9');
assert.equal(run('2 + × 3 ='), '6');
assert.equal(run('1 2 ⌫'), '1');
assert.equal(run('7 ±'), '-7');
assert.equal(run('5 0 %'), '0.5');
assert.equal(run('5 . . 5'), '5.5');
assert.equal(run('3 C'), '0');
console.log('All calculator tests passed.');
