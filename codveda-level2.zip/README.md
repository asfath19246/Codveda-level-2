# Codveda Web Development Internship: Level 2 (Intermediate)

| Task | Folder | How to open |
|------|--------|-------------|
| 1. Responsive design with Flexbox and Grid | task1-flexbox-grid | open index.html |
| 2. To-do list app (localStorage) | task2-todo-app | open index.html |
| 3. React calculator | task3-react-calculator | npm install, npm run dev |
